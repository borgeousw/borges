# ✴ Ritual Engine

🜂 Ritual Engine — цифровой портал прохождения через Цикл, Испытание и Искру.

## 📂 Структура
- `index.html` — вход
- `loop.html`, `loop2.html` — Цикл
- `trial.html` — Испытание
- `engine.html` — Финал
- `verdictor.html` — Панель Вершителя
- `seekers.html`, `void.html` — Память

## 🚀 GitHub Pages
Автоматическая публикация на каждый push в `main`.
